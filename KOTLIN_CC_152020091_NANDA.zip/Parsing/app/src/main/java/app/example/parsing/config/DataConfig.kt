package app.example.parsing.config

import app.example.parsing.model.ModelGempa
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

class DataConfig {

        // set interceptor
        fun getInterceptor() : OkHttpClient {
            val logging = HttpLoggingInterceptor()
            logging.level = HttpLoggingInterceptor.Level.BODY
            val okHttpClient = OkHttpClient.Builder()
                .addInterceptor(logging)
                .build()
            return  okHttpClient
        }
        fun getRetrofit() : Retrofit {
            return Retrofit.Builder()
                .baseUrl("https://data.bmkg.go.id/DataMKG/TEWS/")
                .client(getInterceptor())
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        fun getService() = getRetrofit().create(EarthQuake::class.java)
    }

interface EarthQuake {
    @GET("autogempa.json")
    fun getDataGempa(): Call<ModelGempa>
}

